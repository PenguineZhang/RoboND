All meshes in this directory (except gripper) were obtained from https://github.com/pr2/pr2_common
