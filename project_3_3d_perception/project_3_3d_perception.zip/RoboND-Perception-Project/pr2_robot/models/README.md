The mesh files for models listed below were obtained from http://rll.berkeley.edu/amazon_picking_challenge/
- biscuits
- book
- eraser
- glue
- snacks
- soap
- soap2
- sticky_notes
