This package was obtained from: https://github.com/JenniferBuehler/gazebo-pkgs
