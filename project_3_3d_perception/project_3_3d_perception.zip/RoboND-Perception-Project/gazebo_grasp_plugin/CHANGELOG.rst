^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gazebo_grasp_plugin
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2016-06-08)
------------------
* Fixed cmake files for jenkins builds
* Contributors: Jennifer Buehler

1.0.0 (2016-06-07)
------------------
* Initial release
* Contributors: Jennifer Buehler
